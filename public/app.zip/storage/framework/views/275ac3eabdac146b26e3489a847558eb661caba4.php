
<?php $__env->startSection('title', 'Auto Token Setting'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.auto_token_setting')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body">
        <!-- setting form -->
        <div class="col-sm-6">  
            <?php echo e(Form::open(['url' => 'admin/token/setting'])); ?>


                <div class="form-group <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="department_id"><?php echo e(trans('app.department')); ?> <i class="text-danger">*</i></label><br/>
                    <?php echo e(Form::select('department_id', $departmentList, null, ['placeholder' => 'Select Option', 'class'=>'select2 form-control'])); ?><br/>
                    <span class="text-danger"><?php echo e($errors->first('department_id')); ?></span>
                </div> 

                <div class="form-group <?php $__errorArgs = ['counter_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="counter"><?php echo e(trans('app.counter')); ?> <i class="text-danger">*</i></label><br/>
                    <?php echo e(Form::select('counter_id', $countertList, null, ['placeholder' => 'Select Option', 'class'=>'select2 form-control'])); ?><br/>
                    <span class="text-danger"><?php echo e($errors->first('counter_id')); ?></span> 
                </div> 

                <div class="form-group <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="officer"><?php echo e(trans('app.officer')); ?> <i class="text-danger">*</i></label><br/>
                    <?php echo e(Form::select('user_id', $userList, null, ['placeholder' => 'Select Option', 'class'=>'select2 form-control'])); ?><br/>
                    <span class="text-danger"><?php echo e($errors->first('user_id')); ?></span>
                </div> 
                
                <div class="btn-group">
                    <button type="reset" class="btn btn-primary"><?php echo e(trans('app.reset')); ?></button>
                    <button type="submit" class="btn btn-success"><?php echo e(trans('app.save')); ?></button> 
                </div>
            
            <?php echo e(Form::close()); ?>

        </div>

        <!-- display setting option -->
        <div class="col-sm-6">
            <table class="display table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th> 
                        <th><?php echo e(trans('app.department')); ?></th>
                        <th><?php echo e(trans('app.counter')); ?></th>
                        <th><?php echo e(trans('app.officer')); ?></th> 
                        <th><?php echo e(trans('app.action')); ?></th>
                    </tr>
                </thead> 
                <tbody>

                    <?php if(!empty($tokens)): ?>
                        <?php $sl = 1 ?>
                        <?php $__currentLoopData = $tokens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $token): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sl++); ?></td> 
                                <td><?php echo e($token->department); ?></td>
                                <td><?php echo e($token->counter); ?></td>
                                <td><?php echo e($token->firstname); ?> <?php echo e($token->lastname); ?></td>
                                <td>
                                    <div class="btn-group">   
                                        <a href="<?php echo e(url("admin/token/setting/delete/$token->id")); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')" title="Delete"><i class="fa fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div> 
</div>  
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deltabd/public_html/resources/views/backend/admin/token/setting.blade.php ENDPATH**/ ?>