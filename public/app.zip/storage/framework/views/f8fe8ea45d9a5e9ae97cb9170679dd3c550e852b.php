
<?php $__env->startSection('title', trans('app.display_2')); ?>


<?php $__env->startSection('content'); ?> 
<div class="panel panel-primary">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12">
                <h3><?php echo e(trans('app.display_2')); ?> <button class="pull-right btn btn-sm btn-primary" onclick="goFullscreen('fullscreen'); return false"><i class="fa fa-arrows-alt" aria-hidden="true"></i></button></h3> 
                <span class="text-danger">(enable full-screen mode and wait 10 seconds to adjust the screen)</span>
            </div> 
        </div>
    </div>

    <div class="panel-body" id="fullscreen" style="color:<?php echo e((!empty($setting->color)?$setting->color:'#ffffff')); ?>">
 
      <div class="media" style="height:60px;background:#3498db;margin-top:-20px;margin-bottom:10px">
        <div class="media-left hidden-xs">
          <img class="media-object" style="height:59px;" src="<?php echo e(asset('public/assets/img/icons/logo.jpg')); ?>" alt="Logo">
        </div>
        <div class="media-body" style="color:#ffffff">
          <h4 class="media-heading" style="font-size:50px;line-height:60px"><marquee direction="<?php echo e((!empty($setting->direction)?$setting->direction:null)); ?>"><?php echo e((!empty($setting->message)?$setting->message:null)); ?></marquee></h4> 
        </div>
      </div>
      
      <div class="row">  
         <div id="display5"></div>
      </div>

      <div class="panel-footer col-xs-12"> 
        <?php echo $__env->make('backend.common.info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <span class="col-xs-10 text-left"><?php echo $__env->yieldContent('info.powered-by'); ?></span>
        <span class="col-xs-2 text-right"><?php echo $__env->yieldContent('info.version'); ?></span>
      </div>
    </div> 
</div>   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript"> 
$(document).ready(function(){
  //get previous token
  var view_token = [];
  var interval = 1000; 

  var display = function()
  {
    var width  = $(window).width();
    var height = $(window).height();
    var isFullScreen = document.fullScreen ||
    document.mozFullScreen ||
    document.webkitIsFullScreen || (document.msFullscreenElement != null);
    if (isFullScreen)
    {
      var width  = $(window).width();
      var height = $(window).height();
    } 
    
    $.ajax({
        type:'post',
        dataType:'json',
        url:'<?php echo e(URL::to("common/display5")); ?>',
        data:
        {
            _token: '<?php echo csrf_token() ?>',
            view_token: view_token,
            width: width,
            height: height
        },
        success:function(data)
        {
            $("#display5").html(data.result); 

            view_token = (data.all_token).map(function(item){
                return {counter: item.counter, token  : item.token} 
            }); 

            //notification sound
            if (data.status)
            {  
                var url  = "<?php echo e(URL::to('')); ?>"; 
                var lang = "<?php echo e(in_array(session()->get('locale'), $setting->languages)?session()->get('locale'):'en'); ?>";
                var player = new Notification;
                player.call(data.new_token, lang, url);
            } 

            setTimeout(display, data.interval);
       }
    });
  }; 

  setTimeout(display, interval);
})
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.display', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/deltabd/public_html/resources/views/backend/common/display/display2.blade.php ENDPATH**/ ?>