
<?php $__env->startSection('title', trans('app.display_setting')); ?>

<?php $__env->startSection('content'); ?>
<div class="panel panel-primary" id="printMe">

    <div class="panel-heading">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3><?php echo e(trans('app.display_setting')); ?></h3>
            </div> 
        </div>
    </div>

    <div class="panel-body"> 

        <?php echo e(Form::open(['url' => 'admin/setting/display'])); ?>


        <input type="hidden" name="id" value="<?php echo e($setting->id); ?>">
     
        <div class="col-sm-6">

            <div class="form-group <?php $__errorArgs = ['display'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php 
                    $display = [
                        '1' => trans('app.display_1'),
                        '2' => trans('app.display_2'),
                        '3' => trans('app.display_3'), 
                        '4' => trans('app.display_4'), 
                        '5' => trans('app.display_5')
                    ]; 
                ?>
                <label for="display"><?php echo e(trans('app.display')); ?> </label><br/>
                <?php echo e(Form::select('display', $display , $setting->display , ['placeholder' => trans('app.select_option'), 'class'=>'select2 form-control'])); ?><br/>
                <span class="text-danger"><?php echo e($errors->first('display')); ?></span>
            </div> 

            <div class="form-group <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="message"><?php echo e(trans('app.message')); ?></label> 
                <textarea type="text" name="message" id="message" class="form-control" placeholder="<?php echo e(trans('app.message')); ?>"><?php echo e($setting->message); ?></textarea>
                <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
            </div> 
 
            <div class="form-group <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="direction"><?php echo e(trans('app.direction')); ?></label>
                <div id="direction">  
                    <label class="radio-inline">
                        <input type="radio" name="direction" value="left" <?php echo e((($setting->direction)=='left')?"checked":""); ?>> <?php echo e(trans('app.left')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="direction" value="right" <?php echo e((($setting->direction)=='right')?"checked":""); ?>> <?php echo e(trans('app.right')); ?>

                    </label> 
                </div>
            </div> 
 
            <div class="form-group <?php $__errorArgs = ['time_format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="time_format"><?php echo e(trans('app.time_format')); ?> </label><br/>
                <?php echo e(Form::select('time_format', ['h:i:s A' => '12 Hour', 'H:i:s' => '24 Hour'], $setting->time_format , ['id'=>'time_format', 'class'=>'select2 form-control'])); ?><br/>
                <span class="text-danger"><?php echo e($errors->first('time_format')); ?></span>
            </div> 

            <div class="form-group <?php $__errorArgs = ['date_format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php 
                    $dates = [
                        'd M, Y' => date('d M, Y'),
                        'F j, Y' => date('F j, Y'),
                        'd/m/Y'  => date('d/m/Y'),
                        'm.d.y'  => date('m.d.y') 
                    ]; 
                ?>
                <label for="date_format"><?php echo e(trans('app.date_format')); ?> </label><br/>
                <?php echo e(Form::select('date_format', $dates , $setting->date_format , ['placeholder' => trans('app.select_option'), 'id'=>'date_format', 'class'=>'select2 form-control'])); ?><br/>
                <span class="text-danger"><?php echo e($errors->first('date_format')); ?></span>
            </div> 

            <div class="form-group <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="color"><?php echo e(trans('app.color')); ?></label> 
                <input type="color" name="color" id="color" class="form-control" placeholder="<?php echo e(trans('app.color')); ?>" value="<?php echo e($setting->color); ?>">
                <span class="text-danger"><?php echo e($errors->first('color')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['background_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="background_color"><?php echo e(trans('app.background_color')); ?></label> 
                <input type="color" name="background_color" class="form-control" id="background_color" placeholder="<?php echo e(trans('app.background_color')); ?>" value="<?php echo e($setting->background_color); ?>">
                <span class="text-danger"><?php echo e($errors->first('background_color')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['border_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="border_color"><?php echo e(trans('app.border_color')); ?></label>
                <input type="color" name="border_color" id="border_color" class="form-control" placeholder="<?php echo e(trans('app.border_color')); ?>" value="<?php echo e($setting->border_color); ?>"> 
                <span class="text-danger"><?php echo e($errors->first('border_color')); ?></span>
            </div>
        </div>
  

        <div class="col-sm-6">

            <div class="form-group">
                <h2 for="corn_info">Cron Job Setting for SMS Alert</h2>
                <div class="bg-info well" id="corn_info">
                    You only need to add the following Cron entry to your server to activate schedule sms.  
                    <p class="text-success">* * * * * wget -q -t 5 -O - "http://yourdomain.com/<strong class="text-danger" title="Actual Path of Artisan file">jobs/sms/</strong> </p> 
                </div>
            </div>
 
            <div class="form-group <?php $__errorArgs = ['alert_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="alert_position"><?php echo e(trans('app.alert_position')); ?> <span>(Position of Waiting Before Process)</span></label>
                <input type="text" name="alert_position" id="alert_position" class="form-control" placeholder="<?php echo e(trans('app.alert_position')); ?>" value="<?php echo e($setting->alert_position); ?>">
                <span class="text-danger"><?php echo e($errors->first('alert_position')); ?></span>
            </div>

            <div class="form-group <?php $__errorArgs = ['sms_alert'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="sms_alert"><?php echo e(trans('app.sms_alert')); ?></label>
                <div id="sms_alert">  
                    <label class="radio-inline">
                        <input type="radio" name="sms_alert" value="1" <?php echo e((($setting->sms_alert)=='1')?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="sms_alert" value="0" <?php echo e((($setting->sms_alert)=='0')?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div> 

            <div class="form-group <?php $__errorArgs = ['show_officer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="show_officer"><?php echo e(trans('app.show_officer')); ?></label>
                <div id="show_officer">  
                    <label class="radio-inline">
                        <input type="radio" name="show_officer" value="1" <?php echo e((($setting->show_officer)=='1')?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="show_officer" value="0" <?php echo e((($setting->show_officer)=='0')?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div> 

            <div class="form-group <?php $__errorArgs = ['show_department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="show_department"><?php echo e(trans('app.show_department')); ?></label>
                <div id="show_department">  
                    <label class="radio-inline">
                        <input type="radio" name="show_department" value="1" <?php echo e((($setting->show_department)=='1')?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="show_department" value="0" <?php echo e((($setting->show_department)=='0')?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div> 

            <div class="form-group <?php $__errorArgs = ['show_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="show_note"><?php echo e(trans('app.show_note')); ?></label>
                <div id="show_note">  
                    <label class="radio-inline">
                        <input type="radio" name="show_note" value="1" <?php echo e((($setting->show_note)=='1')?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="show_note" value="0" <?php echo e((($setting->show_note)=='0')?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div> 

            <div class="form-group <?php $__errorArgs = ['keyboard_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="keyboard_mode"><?php echo e(trans('app.keyboard_mode')); ?></label>
                <div id="keyboard_mode">  
                    <label class="radio-inline">
                        <input type="radio" name="keyboard_mode" value="1" <?php echo e((($setting->keyboard_mode)=='1')?"checked":""); ?>> <?php echo e(trans('app.active')); ?>

                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="keyboard_mode" value="0" <?php echo e((($setting->keyboard_mode)=='0')?"checked":""); ?>> <?php echo e(trans('app.deactive')); ?>

                    </label> 
                </div>
            </div>

            <div class="form-group">
                <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
                <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.update')); ?></span></button> 
            </div>
        </div>
        
        <?php echo e(Form::close()); ?>


    </div> 
</div> 


<!-- Custom Display -->
<div class="panel panel-primary"> 
    <div class="panel-heading"> 
        <ul class="row list-inline m-0">
            <li class="col-xs-10 p-0 text-left">
                <h3><?php echo e(trans('app.custom_display')); ?></h3>
            </li>
            <li class="col-xs-2 p-0 text-right">
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target=".customDisplayModal" data-id="" title="<?php echo e(trans('app.add_display')); ?>">
                    <i class="fa fa-plus"></i>
                </button>
            </li>
        </ul> 
    </div>

    <div class=" panel-body">  
        <table class="datatable table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(trans('app.name')); ?></th>
                    <th><?php echo e(trans('app.counter')); ?></th>
                    <th><?php echo e(trans('app.description')); ?></th>
                    <th><?php echo e(trans('app.status')); ?></th>
                    <th><i class="fa fa-cogs"></i></th> 
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customDisplays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $display): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($display->name); ?></td>
                    <td>
                    <?php if(!empty($display->counters)): ?>
                    <?php $__currentLoopData = explode(',', $display->counters); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php if(!empty($counters[$c])): ?>
                            <span class="label label-success"><?php echo e($counters[$c]); ?></span>&nbsp;
                        <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </td>
                    <td><?php echo e($display->description); ?></td>
                    <td><?php echo (($display->status==1)?"<span class='label label-success'>". trans('app.active') ."</span>":"<span class='label label-danger'>". trans('app.deactive') ."</span>"); ?></td>
                    <td>
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target=".customDisplayModal" title="<?php echo e(trans('app.update_display')); ?>" data-id="<?php echo e($display->id); ?>">
                            <i class="fa fa-edit"></i>
                        </button>
                        <a href="<?php echo e(url('common/display?type=6')); ?>&custom=<?php echo e($display->id); ?>" target="_blank" class="btn btn-success btn-sm" title="<?php echo e(trans('app.display')); ?>">
                            <i class="fa fa-desktop"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table> 
    </div>
</div>

<!-- Modal -->
<div class="modal fade customDisplayModal" tabindex="-1" role="dialog" aria-labelledby="customDisplayModalLabel">
  <div class="modal-dialog" role="document"> 
    <?php echo e(Form::open(['url' => 'admin/setting/display/custom', 'class'=>'modal-content',  'id'=>'customFrm'])); ?>

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="customDisplayModalLabel"><strong></strong> <?= trans('app.custom_display') ?></h4>
      </div>
      <div class="modal-body">  
        <div class="alert mb-1"></div>

        <input type="hidden" name="id" value="">

        <div class="form-group">
            <label for="name"><?php echo e(trans('app.name')); ?> <i class="text-danger">*</i></label> 
            <input type="text" name="name" id="name" class="form-control" placeholder="eg:- Floor 1">
            <span class="text-danger"></span>
        </div>

        <div class="form-group">
            <label for="description"><?php echo e(trans('app.description')); ?></label> 
            <textarea type="text" name="description" id="description" class="form-control" placeholder="<?php echo e(trans('app.description')); ?>"></textarea>
            <span class="text-danger"></span>
        </div>

        <div class="form-group">
            <label for="counters"><?php echo e(trans('app.counter')); ?> <i class="text-danger">*</i></label><br/>
            <?php echo e(Form::select('counters[]', $counters, null, ['id'=>'counters', 'class'=>'select2 form-control', 'multiple'=>'true'])); ?><br/>
            <span class="text-danger"></span>
        </div> 
   
        <div class="form-group">
            <label for="status"><?php echo e(trans('app.status')); ?> <i class="text-danger">*</i></label>
            <div id="status"> 
                <label class="radio-inline">
                    <input type="radio" name="status" value="1" checked> <?php echo e(trans('app.active')); ?>

                </label>
                <label class="radio-inline">
                    <input type="radio" name="status" value="0"> <?php echo e(trans('app.deactive')); ?>

                </label> 
            </div>
            <span class="text-danger"></span>
        </div>   
      </div>
      <div class="modal-footer"> 
            <button class="button btn btn-info" type="reset"><span><?php echo e(trans('app.reset')); ?></span></button>
            <button class="button btn btn-success" type="submit"><span><?php echo e(trans('app.save')); ?></span></button>  
      </div>
    <?php echo e(Form::close()); ?>

  </div>
</div> 
<?php $__env->stopSection(); ?>


<?php $__env->startPush("scripts"); ?>
<script type="text/javascript">
$(document).ready(function(){

    // ready modal form
    $('.customDisplayModal').on('show.bs.modal', function (event) {
        var button    = $(event.relatedTarget);
        var id        = button.data('id');
        var modal     = $(this);
        modal.find('form').get(0).reset();
        modal.find('.alert').hide();
        modal.find('.form-group').removeClass('has-error');
        modal.find('.form-group').find('span.text-danger').html('');
        modal.find('input[name=id]').val(''); 
        modal.find('#counters').val("").trigger("change");
        modal.find('.modal-title strong').html("<i class='fa fa-plus'></i>");
        modal.find('.button[type=submit]').text("<?php echo e(trans('app.save')); ?>");

        if (id != "") {
            modal.find('input[name=id]').val(id);
            modal.find('.modal-title strong').html("<i class='fa fa-pencil'></i>");
            modal.find('button[type=submit]').text("<?php echo e(trans('app.update')); ?>");

            $.ajax({
                url        : '<?php echo e(url("admin/setting/display/custom")); ?>',
                type       : 'get',
                data       : {id},
                dataType   : 'json',
                success: function(response) {
                    var res = response.data;
                    if (response.status) {
                        modal.find('[name=id]').val(res.id);
                        modal.find('[name=name]').val(res.name);
                        modal.find('[name=description]').val(res.description); 
                        modal.find('#counters').val((res.counters).split(',')).trigger("change");
                        modal.find('[name=status][value="'+res.status+'"]').prop('checked', true);  
                    }
                },
                error: function(xhr) {
                    modal.find('.alert').addClass('alert-danger').removeClass('alert-success').show().html('Internal server error! failed to get the content');
                }
            });
        } 
    });
 
    // submit form
    $('#customFrm').on('submit', function(e){
        e.preventDefault();

        var form = $(this); 
        form.find('.form-group').removeClass('has-error');
        form.find('.form-group span.text-danger').html('');

        $.ajax({
            url        : form.attr('action'),
            type       : form.attr('method'),
            dataType   : 'json',
            data       : new FormData(form[0]),
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.status==false) {
                    $.each(response.data, function(field, message){
                        var input = form.find('[name="'+field+'"]');
                        input.closest('.form-group').addClass('has-error');
                        input.closest('.form-group').find('span.text-danger').html(message);
                    });

                    form.find('.alert').addClass('alert-danger').removeClass('alert-success').show().html(response.message);
                } else {
                    form.find('.alert').addClass('alert-success').removeClass('alert-danger').show().html(response.message);
                    setInterval(function(){
                        window.history.go(0);
                    }, 3000);
                }
            },
            error: function(xhr) {
                form.find('.alert').addClass('alert-danger').removeClass('alert-success').show().html('Internal server error! failed to create/update the content');
            }
        });
    });
})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7.3\htdocs\resources\views/backend/admin/display/setting.blade.php ENDPATH**/ ?>