<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class DisplayCustom extends Model
{
    protected $table = "display_custom";
}
